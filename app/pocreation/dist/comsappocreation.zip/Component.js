sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("com.sap.pocreation.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map